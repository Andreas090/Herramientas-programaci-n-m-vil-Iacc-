package com.example.diego_rojas_20260205.repository

import android.content.Context
import com.example.diego_rojas_20260205.data.VisitasDao
import com.example.diego_rojas_20260205.model.Visita
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class VisitasRepository(context: Context) {
    private val visitaDao = VisitasDao(context)

    suspend fun insertarVisita(visita: Visita): Long = withContext(Dispatchers.IO) {
        visitaDao.insertarVisita(visita)
    }

    suspend fun obtenerVisitas(): List<Visita> = withContext(Dispatchers.IO) {
        visitaDao.obtenerVisitas()
    }

    suspend fun actualizarFechaHoraSalida(id: Long, fechaHoraSalida: String): Boolean =
        withContext(Dispatchers.IO) {
            visitaDao.actualizarFechaHoraSalida(id, fechaHoraSalida) > 0
        }

    suspend fun obtenerVisitaId(id: Long): Visita? = withContext(Dispatchers.IO) {
        visitaDao.obtenerVisitaId(id)

    }
}