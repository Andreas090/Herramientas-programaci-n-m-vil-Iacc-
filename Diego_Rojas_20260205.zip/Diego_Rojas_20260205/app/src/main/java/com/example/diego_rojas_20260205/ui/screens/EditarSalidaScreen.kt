package com.example.diego_rojas_20260205.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CalendarToday
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.diego_rojas_20260205.model.Visita
import com.example.diego_rojas_20260205.viewmodel.VisitasViewModel
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditarSalidaScreen(
    visita: Visita,
    viewModel: VisitasViewModel,
    onNavigateBack: () -> Unit
) {
    var fechaSalida by remember {
        mutableStateOf(
            visita.fechaHoraSalida ?: SimpleDateFormat(
                "yyyy-MM-dd HH:mm:ss",
                Locale.getDefault()
            ).format(Date())
        )
    }

    var mostrarDialogoFecha by remember { mutableStateOf(false) }
    var mostrarDialogoHora by remember { mutableStateOf(false) }

    val mensajeConfirmacion by viewModel.mensajeConfirmacion.collectAsState()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(mensajeConfirmacion) {
        mensajeConfirmacion?.let { mensaje ->
            snackbarHostState.showSnackbar(mensaje)
            viewModel.limpiarMensaje()
            delay(1000)
            onNavigateBack()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        "Registrar Salida",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF5B5FCF),
                    titleContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF5F5F5))
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Card con información del visitante
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Información del Visitante",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF5B5FCF)
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    InfoRow(label = "Nombre", value = "${visita.nombre} ${visita.apellido}")
                    Spacer(modifier = Modifier.height(8.dp))
                    InfoRow(label = "RUT", value = visita.rut)
                    Spacer(modifier = Modifier.height(8.dp))
                    InfoRow(label = "Departamento", value = visita.departamento)
                    Spacer(modifier = Modifier.height(8.dp))
                    InfoRow(
                        label = "Ingreso",
                        value = formatearFechaHora(visita.fechaHoraIngreso)
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Card para seleccionar fecha y hora de salida
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = Color.White
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Text(
                        text = "Fecha y Hora de Salida",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Mostrar fecha y hora actual seleccionada
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = Color(0xFFF5F5F5)
                    ) {
                        Column(
                            modifier = Modifier.padding(16.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = formatearFechaHora(fechaSalida),
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Medium,
                                color = Color(0xFF5B5FCF)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Botones para cambiar fecha y hora
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { mostrarDialogoFecha = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFF5B5FCF)
                            )
                        ) {
                            Icon(
                                Icons.Default.CalendarToday,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Fecha")
                        }

                        OutlinedButton(
                            onClick = { mostrarDialogoHora = true },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.outlinedButtonColors(
                                contentColor = Color(0xFF5B5FCF)
                            )
                        ) {
                            Icon(
                                Icons.Default.Schedule,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Hora")
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Botón Usar Hora Actual
                    TextButton(
                        onClick = {
                            fechaSalida = SimpleDateFormat(
                                "yyyy-MM-dd HH:mm:ss",
                                Locale.getDefault()
                            ).format(Date())
                        },
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    ) {
                        Text(
                            "Usar fecha y hora actual",
                            color = Color(0xFF5B5FCF)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Botón Guardar
            Button(
                onClick = {
                    viewModel.actualizarFechaSalida(visita.id, fechaSalida)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF5B5FCF)
                )
            ) {
                Text(
                    text = "GUARDAR SALIDA",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }

    // Diálogo para seleccionar fecha
    if (mostrarDialogoFecha) {
        val datePickerState = rememberDatePickerState()

        DatePickerDialog(
            onDismissRequest = { mostrarDialogoFecha = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        datePickerState.selectedDateMillis?.let { millis ->
                            val calendar = Calendar.getInstance()
                            calendar.timeInMillis = millis

                            // Mantener la hora actual
                            val formatoActual =
                                SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                            val fechaActual = formatoActual.parse(fechaSalida)
                            fechaActual?.let {
                                val calActual = Calendar.getInstance()
                                calActual.time = it

                                calendar.set(
                                    Calendar.HOUR_OF_DAY,
                                    calActual.get(Calendar.HOUR_OF_DAY)
                                )
                                calendar.set(Calendar.MINUTE, calActual.get(Calendar.MINUTE))
                                calendar.set(Calendar.SECOND, calActual.get(Calendar.SECOND))
                            }

                            fechaSalida = SimpleDateFormat(
                                "yyyy-MM-dd HH:mm:ss",
                                Locale.getDefault()
                            ).format(calendar.time)
                        }
                        mostrarDialogoFecha = false
                    }
                ) {
                    Text("Aceptar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogoFecha = false }) {
                    Text("Cancelar")
                }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    // Diálogo para seleccionar hora
    if (mostrarDialogoHora) {
        val timePickerState = rememberTimePickerState()

        AlertDialog(
            onDismissRequest = { mostrarDialogoHora = false },
            confirmButton = {
                TextButton(
                    onClick = {
                        val formatoActual =
                            SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                        val fechaActual = formatoActual.parse(fechaSalida)

                        val calendar = Calendar.getInstance()
                        fechaActual?.let { calendar.time = it }

                        calendar.set(Calendar.HOUR_OF_DAY, timePickerState.hour)
                        calendar.set(Calendar.MINUTE, timePickerState.minute)
                        calendar.set(Calendar.SECOND, 0)

                        fechaSalida = formatoActual.format(calendar.time)
                        mostrarDialogoHora = false
                    }
                ) {
                    Text("Aceptar")
                }
            },
            dismissButton = {
                TextButton(onClick = { mostrarDialogoHora = false }) {
                    Text("Cancelar")
                }
            },
            text = {
                TimePicker(state = timePickerState)
            }
        )
    }
}

