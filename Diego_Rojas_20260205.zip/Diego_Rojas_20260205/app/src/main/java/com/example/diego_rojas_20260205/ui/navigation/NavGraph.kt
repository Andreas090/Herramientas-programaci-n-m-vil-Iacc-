package com.example.diego_rojas_20260205.ui.navigation


import android.content.Intent
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.diego_rojas_20260205.model.Visita
import com.example.diego_rojas_20260205.ui.screens.EditarSalidaScreen
import com.example.diego_rojas_20260205.ui.screens.ListaVisitasScreen
import com.example.diego_rojas_20260205.ui.screens.RegistroVisitaScreen
import com.example.diego_rojas_20260205.viewmodel.VisitasViewModel
import androidx.compose.ui.platform.LocalContext

sealed class Screen(val route: String) {
    object Registro : Screen("registro")
    object Lista : Screen("lista")
    object EditarSalida : Screen("editar_salida")
}

@Composable
fun NavGraph(
    navController: NavHostController = rememberNavController(),
    viewModel: VisitasViewModel = viewModel()
) {
    val context = LocalContext.current

    // Variable para pasar la visita entre pantallas - CORREGIDO
    var visitaSeleccionada by remember { mutableStateOf<Visita?>(null) }

    NavHost(
        navController = navController,
        startDestination = Screen.Registro.route
    ) {
        composable(Screen.Registro.route) {
            RegistroVisitaScreen(
                viewModel = viewModel,
                onNavigateToList = {
                    navController.navigate(Screen.Lista.route)
                }
            )
        }

        composable(Screen.Lista.route) {
            ListaVisitasScreen(
                viewModel = viewModel,
                onNavigateBack = {
                    navController.popBackStack()
                },
                onEditarSalida = { visita ->
                    visitaSeleccionada = visita
                    navController.navigate(Screen.EditarSalida.route)
                },
                onCompartir = { visita ->
                    compartirVisita(context, visita)
                }
            )
        }

        composable(Screen.EditarSalida.route) {
            visitaSeleccionada?.let { visita ->
                EditarSalidaScreen(
                    visita = visita,
                    viewModel = viewModel,
                    onNavigateBack = {
                        navController.popBackStack()
                    }
                )
            }
        }
    }
}

fun compartirVisita(context: android.content.Context, visita: Visita) {
    val textoCompartir = buildString {
        appendLine("📋 REGISTRO DE VISITA")
        appendLine("━━━━━━━━━━━━━━━━━━━")
        appendLine("👤 Visitante: ${visita.nombre} ${visita.apellido}")
        appendLine("🆔 RUT: ${visita.rut}")
        appendLine("🏠 Destino: ${visita.departamento}")
        appendLine("⏱ Ingreso: ${visita.fechaHoraIngreso}")
        appendLine("⏱ Salida: ${visita.fechaHoraSalida ?: "Pendiente"}")
        appendLine("━━━━━━━━━━━━━━━━━━━")
        appendLine("Generado por Mi Administración")
    }

    val intent = Intent(Intent.ACTION_SEND).apply {
        type = "text/plain"
        putExtra(Intent.EXTRA_SUBJECT, "Registro de Visita - ${visita.nombre} ${visita.apellido}")
        putExtra(Intent.EXTRA_TEXT, textoCompartir)
    }

    context.startActivity(Intent.createChooser(intent, "Compartir visita mediante"))
}