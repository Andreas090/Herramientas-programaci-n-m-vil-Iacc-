package com.example.diego_rojas_20260205.data

import android.provider.BaseColumns


object VisitasContract {

    object VisitasEntry : BaseColumns {
        const val TABLE_NAME = "visitas"
        const val COLUMN_ID = BaseColumns._ID
        const val COLUMN_RUT = "rut"
        const val COLUMN_NOMBRE = "nombre"
        const val COLUMN_APELLIDO = "apellido"
        const val COLUMN_FECHA_HORA_INGRESO = "fecha_hora_ingreso"
        const val COLUMN_DEPARTAMENTO = "departamento"
        const val COLUMN_FECHA_HORA_SALIDA = "fecha_hora_salida"
    }

    const val SQL_CREATE_ENTRIES =
        "CREATE TABLE ${VisitasEntry.TABLE_NAME} (" +
                "${VisitasEntry.COLUMN_ID} INTEGER PRIMARY KEY AUTOINCREMENT," +
                "${VisitasEntry.COLUMN_RUT} TEXT NOT NULL," +
                "${VisitasEntry.COLUMN_NOMBRE} TEXT NOT NULL," +
                "${VisitasEntry.COLUMN_APELLIDO} TEXT NOT NULL," +
                "${VisitasEntry.COLUMN_FECHA_HORA_INGRESO} TEXT NOT NULL," +
                "${VisitasEntry.COLUMN_DEPARTAMENTO} TEXT NOT NULL," +
                "${VisitasEntry.COLUMN_FECHA_HORA_SALIDA} TEXT)"

    const val SQL_DELETE_ENTRIES = "DROP TABLE IF EXISTS ${VisitasEntry.TABLE_NAME}"

}