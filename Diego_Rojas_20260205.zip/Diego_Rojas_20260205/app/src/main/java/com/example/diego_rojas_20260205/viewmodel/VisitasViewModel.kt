package com.example.diego_rojas_20260205.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.diego_rojas_20260205.model.Visita
import com.example.diego_rojas_20260205.repository.VisitasRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class VisitasViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = VisitasRepository(application)

    private val _visitas = MutableStateFlow<List<Visita>>(emptyList())
    val visitas: StateFlow<List<Visita>> = _visitas.asStateFlow()

    private val _mensajeConfirmacion = MutableStateFlow<String?>(null)
    val mensajeConfirmacion: StateFlow<String?> = _mensajeConfirmacion.asStateFlow()

    init {
        cargarVisitas()
    }

    fun cargarVisitas(){
        viewModelScope.launch {
            _visitas.value = repository.obtenerVisitas()
        }
    }

    fun insertarVisita(visita: Visita){
        viewModelScope.launch {
            val resultado = repository.insertarVisita(visita)
            if (resultado > 0){
                _mensajeConfirmacion.value = "Visita registrada correctamente"
                cargarVisitas()
            } else {
                _mensajeConfirmacion.value = "Error al registrar la visita"
            }
        }
    }

    fun actualizarFechaSalida(id: Long, fechaHoraSalida: String){
        viewModelScope.launch {
            val resultado = repository.actualizarFechaHoraSalida(id, fechaHoraSalida)
            if (resultado){
                _mensajeConfirmacion.value = "Fecha de salida actualizada correctamente"
                cargarVisitas()
            } else {
                _mensajeConfirmacion.value = "Error al actualizar la fecha de salida"
            }
        }
    }

    fun limpiarMensaje(){
        _mensajeConfirmacion.value = null
    }
}


