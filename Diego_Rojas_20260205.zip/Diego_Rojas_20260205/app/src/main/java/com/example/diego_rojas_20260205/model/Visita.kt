package com.example.diego_rojas_20260205.model

data class Visita (
    val id: Long = 0,
    val rut: String,
    val nombre: String,
    val apellido: String,
    val fechaHoraIngreso: String,
    val departamento: String,
    val fechaHoraSalida: String? = null


)