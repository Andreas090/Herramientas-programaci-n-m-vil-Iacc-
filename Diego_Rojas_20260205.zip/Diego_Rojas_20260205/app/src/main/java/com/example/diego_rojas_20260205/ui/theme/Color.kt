package com.example.diego_rojas_20260205.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryBlue = Color(0xFF5B5FCF)
val LightBackground = Color(0xFFF5F5F5)
val CardBackground = Color(0xFFFFFFFF)
val TextPrimary = Color(0xFF1A1A1A)
val TextSecondary = Color(0xFF666666)
val TextHint = Color(0xFFA1A1A1)
val BorderColor = Color(0xFFE0E0E0)
