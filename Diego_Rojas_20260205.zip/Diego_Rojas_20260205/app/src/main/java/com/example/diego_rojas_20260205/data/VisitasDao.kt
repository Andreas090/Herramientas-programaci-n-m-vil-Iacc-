package com.example.diego_rojas_20260205.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import com.example.diego_rojas_20260205.model.Visita

class VisitasDao (context: Context) {

    private val dbHelper = VisitasDbHelper(context)

    // insertar una nueva visita
    fun insertarVisita(visita: Visita): Long {
        return dbHelper.writableDatabase.use { db ->
            val values = ContentValues().apply {
                put(VisitasContract.VisitasEntry.COLUMN_RUT, visita.rut)
                put(VisitasContract.VisitasEntry.COLUMN_NOMBRE, visita.nombre)
                put(VisitasContract.VisitasEntry.COLUMN_APELLIDO, visita.apellido)
                put(VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_INGRESO, visita.fechaHoraIngreso)
                put(VisitasContract.VisitasEntry.COLUMN_DEPARTAMENTO, visita.departamento)
                put(VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_SALIDA, visita.fechaHoraSalida)
            }
            db.insert(VisitasContract.VisitasEntry.TABLE_NAME, null, values)
        }
    }

    // Obtener todas las visitas registradas
    fun obtenerVisitas(): List<Visita> {
        val db = dbHelper.readableDatabase
        val visitas = mutableListOf<Visita>()

        val cursor: Cursor = db.query(
            VisitasContract.VisitasEntry.TABLE_NAME,
            null,
            null,
            null,
            null,
            null,
            "${VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_INGRESO} DESC"
        )

        cursor.use {
            while (it.moveToNext()) {
                val visita = Visita(
                    id = it.getLong(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_ID)),
                    rut = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_RUT)),
                    nombre = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_NOMBRE)),
                    apellido = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_APELLIDO)),
                    fechaHoraIngreso = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_INGRESO)),
                    departamento = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_DEPARTAMENTO)),
                    fechaHoraSalida = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_SALIDA))
                )
                visitas.add(visita)
            }
        }
        return visitas
    }

    // Actualizar fecha y hora de salida de una visita

    fun actualizarFechaHoraSalida(id: Long, fechaHoraSalida: String): Int {
        return dbHelper.writableDatabase.use { db ->
            val values = ContentValues().apply {
                put(VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_SALIDA, fechaHoraSalida)
            }

            val selection = "${VisitasContract.VisitasEntry.COLUMN_ID} = ?"
            val selectionArgs = arrayOf(id.toString())

            db.update(
                VisitasContract.VisitasEntry.TABLE_NAME,
                values,
                selection,
                selectionArgs
            )
        }
    }

    // obtener una visita por ID

    fun obtenerVisitaId(id: Long): Visita? {
        val db = dbHelper.readableDatabase

        val selection = "${VisitasContract.VisitasEntry.COLUMN_ID} = ?"
        val selectionArgs = arrayOf(id.toString())

        val cursor = db.query(
            VisitasContract.VisitasEntry.TABLE_NAME,
            null,
            selection,
            selectionArgs,
            null,
            null,
            null
        )

        return cursor.use {
            if (it.moveToFirst()) {
                Visita(
                    id = it.getLong(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_ID)),
                    rut = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_RUT)),
                    nombre = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_NOMBRE)),
                    apellido = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_APELLIDO)),
                    fechaHoraIngreso = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_INGRESO)),
                    departamento = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_DEPARTAMENTO)),
                    fechaHoraSalida = it.getString(it.getColumnIndexOrThrow(VisitasContract.VisitasEntry.COLUMN_FECHA_HORA_SALIDA))
                )
            } else {
                null
            }
        }
    }

}