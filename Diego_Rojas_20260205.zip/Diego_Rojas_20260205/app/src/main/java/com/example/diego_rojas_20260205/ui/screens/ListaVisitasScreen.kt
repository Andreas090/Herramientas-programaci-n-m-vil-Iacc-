package com.example.diego_rojas_20260205.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.diego_rojas_20260205.model.Visita
import com.example.diego_rojas_20260205.viewmodel.VisitasViewModel
import java.text.SimpleDateFormat
import java.util.Locale


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ListaVisitasScreen(
    viewModel: VisitasViewModel,
    onNavigateBack: () -> Unit,
    onEditarSalida: (Visita) -> Unit,
    onCompartir: (Visita) -> Unit
) { val visitas by viewModel.visitas.collectAsState()

    LaunchedEffect(Unit){
        viewModel.cargarVisitas()
    }
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Registro de Visitas") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack){
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Volver",
                            tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF5B5FCF),
                    titleContentColor = Color.White
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFFF5F5F5))
                .padding(paddingValues)
        ){
            if(visitas.isEmpty()){
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ){
                        Icon(
                            Icons.Default.Person,
                            contentDescription = null,
                            modifier = Modifier.size(80.dp),
                            tint = Color(0xFFCCCCCC)
                        )
                        Text(
                            "No hay visitas registradas",
                            fontSize = 18.sp,
                            color = Color(0xFF666666)

                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(visitas, key = { it.id }) { visita ->
                        VisitaCard(
                            visita = visita,
                            onEditarSalida = { onEditarSalida(visita) },
                            onCompartir = { onCompartir(visita)}
                        )
                    }
                }
            }
        }

    }
}

@Composable
fun VisitaCard(
    visita: Visita,
    onEditarSalida: () -> Unit,
    onCompartir: () -> Unit
){
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = Color.White
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ){
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)

        ){
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ){
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "${visita.nombre} ${visita.apellido}",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1A1A1A)
                    )
                    Text(
                        text = "Rut: ${visita.rut}",
                        fontSize = 14.sp,
                        color = Color(0xFF666666)
                    )
                }
                // indicador del estado
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (visita.fechaHoraSalida != null)
                        Color(0xFFE8F5E9) else Color(0xFFFFF3E0)
                ) {

                    Text(
                        text = if (visita.fechaHoraSalida != null) "Salió" else "En visita",
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = if (visita.fechaHoraSalida != null)
                            Color(0xFF2E7D32) else Color(0xFFE65100)
                    )
                }

            }
            Spacer(modifier = Modifier.height(12.dp))

            HorizontalDivider(color = Color(0xFFE0E0E0))

            Spacer(modifier = Modifier.height(12.dp))

            // informacion detallada
            InfoRow(label = "Departamento", value = visita.departamento)

            Spacer(modifier = Modifier.height(8.dp))

            InfoRow(label = "Ingreso", value = visita.fechaHoraIngreso)


            InfoRow(label = "Salida", value = visita.fechaHoraSalida?.let{formatearFechaHora(it)} ?: "Pendiente")


            Spacer(modifier = Modifier.height(12.dp))

            // Botones de accion

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)

            ){
                // Boton registrar/editar salida
                OutlinedButton(
                    onClick = onEditarSalida,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = Color(0xFF5B5FCF)
                    )
                ){
                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (visita.fechaHoraSalida != null) "Editar" else "Salida",
                        fontSize = 14.sp
                    )
                }

                // Boton compartir
                Button(
                    onClick = onCompartir,
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF5B5FCF)
                    )
                 ){
                    Icon(
                        Icons.Default.Share,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Compartir",
                        fontSize = 14.sp
                    )

                }
            }

        }
    }
}

@Composable
fun InfoRow(label: String, value: String){
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween

    ){ 
        Text(
            text = label,
            fontSize = 14.sp,
            color = Color(0xFF666666),
            fontWeight = FontWeight.Medium
        )
        Text(
            text = value, 
            fontSize = 14.sp,
            color = Color(0xFF1A1A1A),
            fontWeight = FontWeight.Medium
        )
        
        
    }
}

fun formatearFechaHora(fechaHora: String): String {
    return try {
        val formatoEntrada = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        val formatoSalida = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        val fecha = formatoEntrada.parse(fechaHora) 
        fecha?.let { formatoSalida.format(it)} ?: fechaHora
    } catch (e: Exception){
        fechaHora
    }
}
