package com.example.diego_rojas_20260205.data

import android.content.ContentProvider
import android.content.ContentUris
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.net.Uri

class VisitasContentProvider : ContentProvider() {

    private lateinit var dbHelper: VisitasDbHelper

    companion object {
        private const val AUTHORITY = "com.example.diego_rojas_20260205.provider"
        private const val VISITAS = 1
        private const val VISITA_ID = 2

        val CONTENT_URI: Uri = Uri.parse("content://$AUTHORITY/visitas")

        private val uriMatcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(AUTHORITY, "visitas", VISITAS)
            addURI(AUTHORITY, "visitas/#", VISITA_ID)
        }
    }

    override fun onCreate(): Boolean {
        dbHelper = context?.let { VisitasDbHelper(it) } ?: return false
        return true
    }

    override fun query(
        uri: Uri,
        projection: Array<out String>?,
        selection: String?,
        selectionArgs: Array<out String>?,
        sortOrder: String?
    ): Cursor? {
        val db = dbHelper.readableDatabase

        val cursor = when (uriMatcher.match(uri)) {
            VISITAS -> {
                db.query(
                    VisitasContract.VisitasEntry.TABLE_NAME,
                    projection,
                    selection,
                    selectionArgs,
                    null,
                    null,
                    sortOrder
                )
            }
            VISITA_ID -> {
                val id = ContentUris.parseId(uri)
                val newSelection = "${VisitasContract.VisitasEntry.COLUMN_ID} = ?"
                val newSelectionArgs = arrayOf(id.toString())

                db.query(
                    VisitasContract.VisitasEntry.TABLE_NAME,
                    projection,
                    newSelection,
                    newSelectionArgs,
                    null,
                    null,
                    sortOrder
                )
            }
            else -> null
        }

        cursor?.setNotificationUri(context?.contentResolver, uri)
        return cursor
    }

    override fun getType(uri: Uri): String? {
        return when (uriMatcher.match(uri)) {
            VISITAS -> "vnd.android.cursor.dir/vnd.$AUTHORITY.visitas"
            VISITA_ID -> "vnd.android.cursor.item/vnd.$AUTHORITY.visitas"
            else -> null
        }
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        val db = dbHelper.writableDatabase

        val id = when (uriMatcher.match(uri)) {
            VISITAS -> {
                db.insert(VisitasContract.VisitasEntry.TABLE_NAME, null, values)
            }
            else -> -1
        }

        if (id > 0) {
            context?.contentResolver?.notifyChange(uri, null)
            return ContentUris.withAppendedId(CONTENT_URI, id)
        }

        return null
    }

    override fun update(
        uri: Uri,
        values: ContentValues?,
        selection: String?,
        selectionArgs: Array<out String>?
    ): Int {
        val db = dbHelper.writableDatabase

        val count = when (uriMatcher.match(uri)) {
            VISITAS -> {
                db.update(
                    VisitasContract.VisitasEntry.TABLE_NAME,
                    values,
                    selection,
                    selectionArgs
                )
            }
            VISITA_ID -> {
                val id = ContentUris.parseId(uri)
                val newSelection = "${VisitasContract.VisitasEntry.COLUMN_ID} = ?"
                val newSelectionArgs = arrayOf(id.toString())

                db.update(
                    VisitasContract.VisitasEntry.TABLE_NAME,
                    values,
                    newSelection,
                    newSelectionArgs
                )
            }
            else -> 0
        }

        if (count > 0) {
            context?.contentResolver?.notifyChange(uri, null)
        }

        return count
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int {
        val db = dbHelper.writableDatabase

        val count = when (uriMatcher.match(uri)) {
            VISITAS -> {
                db.delete(
                    VisitasContract.VisitasEntry.TABLE_NAME,
                    selection,
                    selectionArgs
                )
            }
            VISITA_ID -> {
                val id = ContentUris.parseId(uri)
                val newSelection = "${VisitasContract.VisitasEntry.COLUMN_ID} = ?"
                val newSelectionArgs = arrayOf(id.toString())

                db.delete(
                    VisitasContract.VisitasEntry.TABLE_NAME,
                    newSelection,
                    newSelectionArgs
                )
            }
            else -> 0
        }

        if (count > 0) {
            context?.contentResolver?.notifyChange(uri, null)
        }

        return count
    }
}